# Agent-Based Intelligent Car Parking Management — Keele University Campus

**Module:** COM748 MSc Research Project — Ulster University  
**Student:** Umer Javed (B01037917)  
**Supervisor:** Nasir Iqbal

---

## Overview

Urban parking search contributes up to 30% of local traffic congestion and
produces an estimated 28 million tonnes of CO₂ globally each year.
University campuses present a structurally distinct problem: permit-based access,
predictable demand cycles driven by lecture schedules, and institutional
sustainability targets.

This project proposes and evaluates an **agent-based parking management system**
for the Keele University campus, implemented in Python using the **Mesa** framework.
A multi-agent allocation system is compared against a first-come-first-served
(FCFS) baseline across 30 simulation replications.

### Results

| Metric | FCFS Baseline | Agent-Based |
|---|---|---|
| Avg. Search Time | 182 s | **124 s** |
| Reduction | — | **31.9% (p = 0.003)** |
| Space Utilisation | 63% | **84%** |
| Est. CO₂ Saving | — | **≈ 54 kg/day (≈ 8.1 t/year)** |

---

## System Architecture

Three cooperating agent types (Wooldridge 2009 hybrid MAS pattern):

| Agent | Role |
|---|---|
| **ManagerAgent** | Supervisory; allocates nearest available bay on a proximity heuristic |
| **SpaceAgent** | One per bay (~2,000); tracks and broadcasts occupancy status |
| **VehicleAgent** | Simulates driver behaviour — arrival, search, park, depart |

Inter-agent communication follows a simplified FIPA-ACL request/inform protocol.

---

## Repository Structure

```
smart-parking-abm/
├── src/
│   ├── agents.py         – VehicleAgent, SpaceAgent, ManagerAgent
│   ├── model.py          – ParkingModel (Mesa); wires agents, data collection
│   ├── preprocess.py     – Timestamp standardisation pipeline for 3 Kaggle datasets
│   └── simulation.py     – 30-replication experiment + paired t-test + results export
├── dashboard/
│   └── app.py            – Streamlit dashboard (KPI cards + interactive charts)
├── data/
│   ├── raw/              – Place downloaded Kaggle CSVs here (git-ignored)
│   ├── processed/        – Output of preprocess.py (git-ignored)
│   ├── results/          – Committed results from the paper run (summary.json + CSV)
│   └── README.md         – Dataset download instructions
├── docs/
│   ├── Final_research_paper.docx
│   └── supporting_material.docx
├── tests/
│   └── test_agents.py    – pytest unit tests
├── requirements.txt
└── .gitignore
```

---

## Datasets

Three Kaggle datasets used as proxy data (no Keele-specific IoT data available):

| Dataset | Records | Timestamp Format | Kaggle |
|---|---|---|---|
| PKLot Parking Occupancy | 695,899 | `DD/MM/YYYY HH:MM` | [link](https://www.kaggle.com/datasets/blanderbuss/parking-lot-dataset) |
| CNRPark+EXT Occupancy | 144,965 | ISO 8601 | [link](https://www.kaggle.com/datasets/ammarnassanalhajali/cnrpark-ext) |
| Smart Parking Sensor Data | 49,120 | Unix epoch | [link](https://www.kaggle.com/datasets/mypapit/smart-parking-system) |

Download the CSVs and place them in `data/raw/` (see `data/README.md`).

---

## Installation

```bash
git clone https://github.com/<your-username>/smart-parking-abm.git
cd smart-parking-abm

python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

---

## Usage

### 1. Preprocess raw datasets

```bash
python src/preprocess.py
```

Standardises timestamps to 15-minute intervals, filters to weekday 08:00–18:00,
calibrates to ~2,000 Keele bays, and outputs `data/processed/unified_parking.csv`.

### 2. Run the simulation

```bash
python src/simulation.py
```

Runs 30 replications of each condition, computes a paired t-test, and saves
results to `data/results/simulation_results.csv` and `data/results/summary.json`.

> **Note:** `data/results/` already contains the committed results from the paper run
> (vehicle arrival seed = 48112). Re-running `simulation.py` overwrites these with a
> new independent run. Results will differ slightly due to stochastic arrivals but
> the qualitative finding is consistent across seeds.

### 3. Streamlit dashboard

```bash
streamlit run dashboard/app.py
```

Opens `http://localhost:8501` showing KPI cards, box plots, and bar charts based
on the results in `data/results/`.

### 4. Tests

```bash
pytest tests/
```

---

## Simulation Design

**Time resolution:** 1 step = 1 minute (`steps_per_hour = 60`).  
FCFS vehicles typically take 2–4 steps (≈ 120–240 s) to find a bay;
the agent-based system reduces this to 1–2 steps (≈ 60–120 s).

**CO₂ estimation (EPA method):**  
Saved search distance = (FCFS mean − agent mean) × 15 km/h cruising × 1,000 vehicles/day.  
Fuel saved: distance / 25 mpg. CO₂: fuel × 8.89 kg/gallon.  
Conservative lower bound — excludes idling and brake/tyre particulates
(Al-Khafajiy et al. 2020; Biswas et al. 2022).

**Statistical testing:** Paired t-test (`scipy.stats.ttest_rel`), 30 replications,
α = 0.05, seeded per ter Hofstede et al. (2023).

---

## Key References

- Liu et al. (2022). Multi-Agent Reinforcement Learning for Smart City Parking. *IEEE TITS.*
- Kazil, Masad & Crooks (2020). Utilizing Python for ABM: The Mesa Framework. *SBP-BRiMS.*
- Al-Khafajiy et al. (2020). Sustainability through Smart Parking. *IEEE IoT J.*
- Wooldridge (2009). *An Introduction to MultiAgent Systems*, 2nd ed. Wiley.
- ter Hofstede, Masad & Bollinger (2023). Validation Practices for Mesa ABMs. *JASSS.*

Full reference list: `docs/Final_research_paper.docx`.
